<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
h1,h2{text-align:center;}
div{margin:20px 300px; background-color:white; border:solid;}
body{background-color:#3F5CAC;}
table{margin-left:100px; margin-top:10px;}
#th1{width:400px;}
#th2{width:100px;}
</style>
</head>

<body>

<?php 

include "db.php";
$sno=$_REQUEST["var1"];


$no=$sno."<br>";

$sql="SELECT sname FROM student where sno='".$sno."';";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
		$Snames=$row["sname"]."<br>";
}
?>
	<h1>Student Information System</h1>
<h2>View Student Information</h2>
<div>
Student Name: <?php echo $Snames ?>
Student No: <?php echo $no ?>
<?php
$sql1="SELECT Scode, Marks FROM follow where SNo='".$sno."';";
$result1=$conn->query($sql1);

echo "
<table border='3'>
<tr><th id='th1'>Subject</th><th id='th2'>Grade</th></tr>";
while($row1=$result1->fetch_assoc()){
	echo"<tr><td>".$row1["Scode"]."</td><td>".$row1["Marks"]."</td></tr>";} 
echo"</table>";


?>

<?php
$conn->close();

?>

</body>
</html>
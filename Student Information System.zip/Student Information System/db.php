<?php
$conn=new MySQLi("localhost","root","","School");
if($conn->connect_error)
{
	die("Connection Error:". $conn->connect_error);
	}




?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
h1,h2{text-align:center;}
body{background-color:#3461B0;}
form{background-color:white; margin:10px 300px; padding-left:200px; border:solid; padding-top:10px;}
</style>
</head>

<body>
<?php

include "db.php";
$sno=$_REQUEST["var1"];

$no=$sno."<br>";
?>
<h1>Student Information System</h1>
<h2>Add New Student</h2>


<form action="" method="post">
Student No: <?php echo $no ?>
Student Name : <input type="text" name="ntext"><br>
<input type="submit" value="Submit" name="submit1">
</form>
<?php
if(isset($_REQUEST["submit1"])){
	$sname= $_REQUEST["ntext"];
	$sql2="INSERT INTO student values('".$sno."','".$sname."')";
	$conn->query($sql2);
	header("location:search.php");
}

$conn->close();
?>
</body>
</html>